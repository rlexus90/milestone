export const LOGIN_URL = 'https://tasks.app.rs.school/angular/login';

export const REGISTERATION_URL =
  'https://tasks.app.rs.school/angular/registration';

export const PROFILE_URL = 'https://tasks.app.rs.school/angular/profile';

export const LOGOUT_URL = 'https://tasks.app.rs.school/angular/logout';

export const GROUP_URL = 'https://tasks.app.rs.school/angular/groups/list';

export const GROUP_GREATE = 'https://tasks.app.rs.school/angular/groups/create';

export const GROUP_DELETE =
  'https://tasks.app.rs.school/angular/groups/delete?groupID=';

export const USER_LIST_URL = 'https://tasks.app.rs.school/angular/users';

export const CONVERSATIONS_LIST_URL =
  'https://tasks.app.rs.school/angular/conversations/list';

export const CONVERSATIONS_GREATE =
  'https://tasks.app.rs.school/angular/conversations/create';

export const GROUP_MESSAGES_URL =
  'https://tasks.app.rs.school/angular/groups/read?groupID=';

export const GROUP_SEND_MSG =
  'https://tasks.app.rs.school/angular/groups/append';

export const CONVERS_MSG =
  'https://tasks.app.rs.school/angular/conversations/read?conversationID=';

export const CONVERS_MSG_SEND =
  'https://tasks.app.rs.school/angular/conversations/append';

export const CONVERS_DELETE =
  'https://tasks.app.rs.school/angular/conversations/delete?conversationID=';

export const USER = {
  email: 'q@q.q',
  password: 'Q!1qwerty',
};
