export interface IMessages {
  authorID: string;
  message: string;
  createdAt: string;
  leftSide: boolean;
}
